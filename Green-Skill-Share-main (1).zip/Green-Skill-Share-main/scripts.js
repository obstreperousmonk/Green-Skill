// Add interactivity (if needed)
document.addEventListener('DOMContentLoaded', () => {
    console.log('Document loaded');
    // Add any interactive JavaScript code here
});
